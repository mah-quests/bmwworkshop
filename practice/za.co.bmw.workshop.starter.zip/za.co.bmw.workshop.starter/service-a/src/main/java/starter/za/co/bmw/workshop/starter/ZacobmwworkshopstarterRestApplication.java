package starter.za.co.bmw.workshop.starter;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 */
@ApplicationPath("/data")
public class ZacobmwworkshopstarterRestApplication extends Application {
}
